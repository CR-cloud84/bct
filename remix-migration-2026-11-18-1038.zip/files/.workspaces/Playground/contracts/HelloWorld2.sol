
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract MyBank
{
    // Stores balance of each customer's wallet address
    mapping(address => uint) private _balances;

    // Deposit money
    function deposit() public payable returns (uint)
    {
        require(msg.value > 0, "Deposit amount must be greater than zero");

        _balances[msg.sender] += msg.value;

        return _balances[msg.sender];
    }

    // Withdraw money
    function withdraw(uint withdrawAmount) public returns (uint)
    {
        require(withdrawAmount > 0, "Amount must be greater than zero");
        require(_balances[msg.sender] >= withdrawAmount, "Insufficient balance");

        _balances[msg.sender] -= withdrawAmount;

        payable(msg.sender).transfer(withdrawAmount);

        return _balances[msg.sender];
    }

    // Show balance
    function viewBalance() public view returns (uint)
    {
        return _balances[msg.sender];
    }
}
