// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title HealthRecords
 * @dev Blockchain based application for managing health-related medical records.
 *
 * IMPORTANT:
 * Actual medical documents should NOT be stored directly on the blockchain.
 * Instead, store the document on IPFS/cloud storage and save its hash on-chain.
 */
contract HealthRecords {

    // ----------------------------------------------------
    // STRUCTURES
    // ----------------------------------------------------

    struct Patient {
        string name;
        uint256 age;
        bool registered;
        address[] authorizedDoctors;
    }

    struct Doctor {
        string name;
        uint256 age;
        string specialization;
        bool registered;
        address[] authorizedPatients;
    }

    struct MedicalRecord {
        uint256 id;
        string diagnosis;
        string recordHash;
        uint256 timestamp;
        address doctor;
    }

    // ----------------------------------------------------
    // STATE VARIABLES
    // ----------------------------------------------------

    mapping(address => Patient) private patients;
    mapping(address => Doctor) private doctors;

    // Patient address => medical records
    mapping(address => MedicalRecord[]) private medicalRecords;

    // Patient => Doctor => access status
    mapping(address => mapping(address => bool)) private doctorAccess;

    address[] private patientList;
    address[] private doctorList;

    uint256 private recordCounter;

    // ----------------------------------------------------
    // EVENTS
    // ----------------------------------------------------

    event PatientRegistered(
        address indexed patientAddress,
        string name
    );

    event DoctorRegistered(
        address indexed doctorAddress,
        string name,
        string specialization
    );

    event AccessGranted(
        address indexed patient,
        address indexed doctor
    );

    event AccessRevoked(
        address indexed patient,
        address indexed doctor
    );

    event MedicalRecordAdded(
        address indexed patient,
        address indexed doctor,
        uint256 recordId,
        string diagnosis,
        string recordHash
    );

    // ----------------------------------------------------
    // MODIFIERS
    // ----------------------------------------------------

    modifier onlyPatient() {
        require(
            patients[msg.sender].registered,
            "Only registered patient can perform this action"
        );
        _;
    }

    modifier onlyDoctor() {
        require(
            doctors[msg.sender].registered,
            "Only registered doctor can perform this action"
        );
        _;
    }

    // ----------------------------------------------------
    // PATIENT REGISTRATION
    // ----------------------------------------------------

    function registerPatient(
        string memory _name,
        uint256 _age
    ) public {

        require(
            !patients[msg.sender].registered,
            "Patient already registered"
        );

        require(
            bytes(_name).length > 0,
            "Name cannot be empty"
        );

        require(
            _age > 0 && _age <= 150,
            "Invalid age"
        );

        patients[msg.sender].name = _name;
        patients[msg.sender].age = _age;
        patients[msg.sender].registered = true;

        patientList.push(msg.sender);

        emit PatientRegistered(
            msg.sender,
            _name
        );
    }

    // ----------------------------------------------------
    // DOCTOR REGISTRATION
    // ----------------------------------------------------

    function registerDoctor(
        string memory _name,
        uint256 _age,
        string memory _specialization
    ) public {

        require(
            !doctors[msg.sender].registered,
            "Doctor already registered"
        );

        require(
            bytes(_name).length > 0,
            "Name cannot be empty"
        );

        require(
            _age > 20 && _age <= 100,
            "Invalid age"
        );

        doctors[msg.sender].name = _name;
        doctors[msg.sender].age = _age;
        doctors[msg.sender].specialization = _specialization;
        doctors[msg.sender].registered = true;

        doctorList.push(msg.sender);

        emit DoctorRegistered(
            msg.sender,
            _name,
            _specialization
        );
    }

    // ----------------------------------------------------
    // GRANT ACCESS
    // ----------------------------------------------------

    function grantDoctorAccess(
        address _doctor
    ) public onlyPatient {

        require(
            doctors[_doctor].registered,
            "Doctor is not registered"
        );

        require(
            !doctorAccess[msg.sender][_doctor],
            "Doctor already has access"
        );

        doctorAccess[msg.sender][_doctor] = true;

        patients[msg.sender].authorizedDoctors.push(_doctor);
        doctors[_doctor].authorizedPatients.push(msg.sender);

        emit AccessGranted(
            msg.sender,
            _doctor
        );
    }

    // ----------------------------------------------------
    // REVOKE ACCESS
    // ----------------------------------------------------

    function revokeDoctorAccess(
        address _doctor
    ) public onlyPatient {

        require(
            doctorAccess[msg.sender][_doctor],
            "Doctor does not have access"
        );

        doctorAccess[msg.sender][_doctor] = false;

        _removeDoctorFromPatientList(
            msg.sender,
            _doctor
        );

        _removePatientFromDoctorList(
            _doctor,
            msg.sender
        );

        emit AccessRevoked(
            msg.sender,
            _doctor
        );
    }

    // ----------------------------------------------------
    // ADD MEDICAL RECORD
    // ----------------------------------------------------

    function addMedicalRecord(
        address _patient,
        string memory _diagnosis,
        string memory _recordHash
    ) public onlyDoctor {

        require(
            patients[_patient].registered,
            "Patient is not registered"
        );

        require(
            doctorAccess[_patient][msg.sender],
            "Doctor does not have patient access"
        );

        require(
            bytes(_diagnosis).length > 0,
            "Diagnosis cannot be empty"
        );

        require(
            bytes(_recordHash).length > 0,
            "Record hash cannot be empty"
        );

        recordCounter++;

        MedicalRecord memory newRecord = MedicalRecord({
            id: recordCounter,
            diagnosis: _diagnosis,
            recordHash: _recordHash,
            timestamp: block.timestamp,
            doctor: msg.sender
        });

        medicalRecords[_patient].push(newRecord);

        emit MedicalRecordAdded(
            _patient,
            msg.sender,
            recordCounter,
            _diagnosis,
            _recordHash
        );
    }

    // ----------------------------------------------------
    // GET PATIENT INFORMATION
    // ----------------------------------------------------

    function getPatient(
        address _patient
    )
        public
        view
        returns (
            string memory name,
            uint256 age
        )
    {
        require(
            patients[_patient].registered,
            "Patient not registered"
        );

        return (
            patients[_patient].name,
            patients[_patient].age
        );
    }

    // ----------------------------------------------------
    // GET DOCTOR INFORMATION
    // ----------------------------------------------------

    function getDoctor(
        address _doctor
    )
        public
        view
        returns (
            string memory name,
            uint256 age,
            string memory specialization
        )
    {
        require(
            doctors[_doctor].registered,
            "Doctor not registered"
        );

        return (
            doctors[_doctor].name,
            doctors[_doctor].age,
            doctors[_doctor].specialization
        );
    }

    // ----------------------------------------------------
    // GET MEDICAL RECORDS
    // ----------------------------------------------------

    function getMedicalRecords(
        address _patient
    )
        public
        view
        returns (MedicalRecord[] memory)
    {
        require(
            patients[_patient].registered,
            "Patient not registered"
        );

        // Patient can view their own records
        if (msg.sender == _patient) {
            return medicalRecords[_patient];
        }

        // Authorized doctor can view records
        require(
            doctors[msg.sender].registered &&
            doctorAccess[_patient][msg.sender],
            "You do not have access to these records"
        );

        return medicalRecords[_patient];
    }

    // ----------------------------------------------------
    // CHECK ACCESS
    // ----------------------------------------------------

    function hasDoctorAccess(
        address _patient,
        address _doctor
    ) public view returns (bool) {

        return doctorAccess[_patient][_doctor];
    }

    // ----------------------------------------------------
    // GET AUTHORIZED DOCTORS
    // ----------------------------------------------------

    function getAuthorizedDoctors(
        address _patient
    )
        public
        view
        returns (address[] memory)
    {
        require(
            patients[_patient].registered,
            "Patient not registered"
        );

        return patients[_patient].authorizedDoctors;
    }

    // ----------------------------------------------------
    // GET AUTHORIZED PATIENTS
    // ----------------------------------------------------

    function getAuthorizedPatients(
        address _doctor
    )
        public
        view
        returns (address[] memory)
    {
        require(
            doctors[_doctor].registered,
            "Doctor not registered"
        );

        return doctors[_doctor].authorizedPatients;
    }

    // ----------------------------------------------------
    // GET ALL PATIENTS
    // ----------------------------------------------------

    function getPatientList()
        public
        view
        returns (address[] memory)
    {
        return patientList;
    }

    // ----------------------------------------------------
    // GET ALL DOCTORS
    // ----------------------------------------------------

    function getDoctorList()
        public
        view
        returns (address[] memory)
    {
        return doctorList;
    }

    // ----------------------------------------------------
    // INTERNAL FUNCTION:
    // REMOVE DOCTOR FROM PATIENT LIST
    // ----------------------------------------------------

    function _removeDoctorFromPatientList(
        address _patient,
        address _doctor
    ) internal {

        address[] storage doctorsList =
            patients[_patient].authorizedDoctors;

        for (uint256 i = 0; i < doctorsList.length; i++) {

            if (doctorsList[i] == _doctor) {

                doctorsList[i] =
                    doctorsList[doctorsList.length - 1];

                doctorsList.pop();

                break;
            }
        }
    }

    // ----------------------------------------------------
    // INTERNAL FUNCTION:
    // REMOVE PATIENT FROM DOCTOR LIST
    // ----------------------------------------------------

    function _removePatientFromDoctorList(
        address _doctor,
        address _patient
    ) internal {

        address[] storage patientsList =
            doctors[_doctor].authorizedPatients;

        for (uint256 i = 0; i < patientsList.length; i++) {

            if (patientsList[i] == _patient) {

                patientsList[i] =
                    patientsList[patientsList.length - 1];

                patientsList.pop();

                break;
            }
        }
    }
}