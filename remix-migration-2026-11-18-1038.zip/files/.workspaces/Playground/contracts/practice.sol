// // // 
// // pragma solidity ^0.8.0;
// // contract bank{
// //     mapping(address=>uint) private _balance;
// //     function deposit() public payable {
// //         require(msg.value>0,"Invalid");
// //         _balance[msg.sender] += msg.value;
// //     }
// //     function withdraw(uint val) public {
// //         require(val>0,"Invalid");
// //         require(val<=_balance[msg.sender],"Invalid, not enought");
// //         _balance[msg.sender] -= val;
// //         payable(msg.sender).transfer(val);
// //     }
// //     function view_balance() public view returns(uint){
// //         return (_balance[msg.sender]);
// //     }

// // }
// pragma  solidity ^0.8.0;

// contract Student{
//     struct student{
//         uint id;
//         string name;
//         uint age;
//         uint marks;
//     }
//     student[] user;
//     function add_student(uint id,string memory name,uint age,uint marks) public{
//         user.push(student(id,name,age,marks));
//     }
//     function view_student(uint id) view public returns(student memory){
//         return user[id];
//     }
// }

pragma solidity ^0.8.0;

contract Bank{
    mapping(address=>uint) _balances;
    function deposit() public payable{
        require(msg.value>0,"Insufficient");
        _balances[msg.sender] += msg.value;
    }
    function withdraw(uint val) public payable{
        require(val>0,"Insufficient");
        require(_balances[msg.sender]>=val,"Invalid");
        _balances[msg.sender] -= val;
        payable(msg.sender).transfer(val);
    }
    function view_balance() public view returns(uint id){
        return _balances[msg.sender];
    }
}